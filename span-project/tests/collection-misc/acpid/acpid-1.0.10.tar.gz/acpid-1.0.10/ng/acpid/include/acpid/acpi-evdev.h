
#include <linux/input.h>
#include "acpi-watch.h"

struct acpi_evdev {
	struct acpi_channel channel;
	int fd;
};

int acpi_evdev_open(struct acpi_evdev *evdev, const char *device);
