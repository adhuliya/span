
#ifndef __ACPID_DRIVER_EVDEV__
#define __ACPID_DRIVER_EVDEV__

#include <acpid/driver.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <linux/input.h>
#include <stdlib.h>

struct acpi_channel_private {
	int fd;
	char hid[32];
};

#endif /* __ACPID_DRIVER_EVDEV__ */

