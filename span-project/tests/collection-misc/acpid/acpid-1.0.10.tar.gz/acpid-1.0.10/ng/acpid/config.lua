
channels = {
	[{ "netlink",	{ "acpi" }			}] = function(...)
		return ...
	end,
	[{ "evdev",	{ "/dev/input/event0" }		}] = function(...)
		return ...
	end,
	[{ "evdev",	{ "/dev/input/event1" }		}] = function(...)
		return ...
	end,
	[{ "evdev",	{ "/dev/input/event2" }		}] = function(...)
		return ...
	end,
	[{ "evdev",	{ "/dev/input/event3" }		}] = function(...)
		return ...
	end,
	[{ "evdev",	{ "/dev/input/event4" }		}] = function(...)
		return ...
	end,
	[{ "evdev",	{ "/dev/input/event5" }		}] = function(...)
		return ...
	end,
}

