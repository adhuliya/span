
#include <dbus/dbus.h>

struct acpi_event {
	char source[30];
	dbus_uint32_t type, code, value;
};

struct acpi_queue {
	int num;
	struct acpi_event events[8];
};

int acpi_queue_put(struct acpi_queue *queue, struct acpi_event *event);
