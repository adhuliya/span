
int acpi_dbus_init()
{
}


