
#ifndef __ACPI_WATCH_H__
#define __ACPI_WATCH_H__

#include <poll.h>

struct acpi_watch {
	int num;
	struct acpi_channel *channels[8];
};

int acpi_watch_init(struct acpi_watch *watch);
int acpi_watch_channel(struct acpi_watch *watch, struct acpi_channel *channel);
int acpi_watch_dispatch(struct acpi_watch *watch, void *arg);

#endif /* __ACPI_WATCH_H__ */

