"""The core of SPAN. Majority of the framework logic is present here.
"""

__all__ = ["clients", "diagnosis", "host"]
