#!/usr/bin/env python3

# MIT License
# Copyright (C) 2021 Anshuman Dhuliya

"""
This is SPAN's automated testing package.

span.tests.run.runTests() is the driver function
that invokes all types of tests in the system.
"""
