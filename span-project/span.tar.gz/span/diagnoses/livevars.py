#!/usr/bin/env python3

# MIT License
# Copyright (c) 2021 Anshuman Dhuliya

"""Counts the number of live vars at each program point."""

import logging
LOG = logging.getLogger(__name__)
LDB = LOG.debug

